"""
Unified Baseline Evaluation for Imbalanced Tabular Classification
==================================================================
Evaluation protocol follows DGOT (IEEE TKDE):
  - Stratified 5-fold cross-validation
  - 10 random seeds per method
  - Per-classifier and averaged reporting with mean +/- std

Classifier hyperparameters (Table III, DGOT paper):
  XGBoost          : max_depth=3, n_estimators=100
  DecisionTree     : max_depth=30
  LogisticRegression: penalty='l2', max_iter=500
  RandomForest     : n_estimators=100
  KNN              : n_neighbors=5

Inline methods:
  Original, SMOTE, Borderline-SMOTE, SMOTE-Tomek, ADASYN,
  KMeansSMOTE, CTGAN, TVAE

Pretrained methods (require separate training):
  DGOT, GOIO

Utility metrics : Accuracy, Macro-F1, MCC, AUC-PR, Balanced Accuracy
Fidelity metrics: MMD (RBF), KS statistic
Privacy metrics : DCR (Distance to Closest Record), MIA (Membership
                  Inference Attack accuracy)
"""

# ============================================================
# 0. DEPENDENCY INSTALLATION
# ============================================================
import subprocess, sys

def _install(pkg):
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "-q", pkg],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

_required = [
    "scikit-learn", "xgboost", "imbalanced-learn", "sdv",
    "pandas", "numpy", "scipy"
]
for _p in _required:
    try:
        __import__(_p.replace("-", "_").split("[")[0])
    except ImportError:
        _install(_p)

# ============================================================
# 1. IMPORTS
# ============================================================
import pandas as pd
import numpy as np
import warnings
import os
import glob
from collections import Counter

from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier, NearestNeighbors
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.metrics import (
    accuracy_score, f1_score, matthews_corrcoef,
    balanced_accuracy_score, average_precision_score,
    roc_auc_score
)
from scipy.stats import ks_2samp
from scipy.spatial.distance import cdist

from imblearn.over_sampling import SMOTE, BorderlineSMOTE, KMeansSMOTE, ADASYN
from imblearn.combine import SMOTETomek

# Try importing TabDDPM and MAT-Diff
try:
    from tab_ddpm.gaussian_multinomial_diffsuion import GaussianMultinomialDiffusion
    from tab_ddpm.modules import MLPDiffusion
    import torch
    TABDDPM_AVAILABLE = True
except ImportError:
    TABDDPM_AVAILABLE = False
    torch = None

try:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from mat_diff.manifold_diffusion import MATDiffPipeline
    MATDIFF_AVAILABLE = True
except ImportError:
    MATDIFF_AVAILABLE = False

warnings.filterwarnings("ignore")

# ============================================================
# 2. CONFIGURATION
# ============================================================
DATASET_NAME = "abalone_15"
N_SEEDS = 10
N_FOLDS = 5

CLASSIFIER_SPECS = [
    ("XGB",   XGBClassifier,         {"max_depth": 3, "n_estimators": 100,
                                      "use_label_encoder": False,
                                      "eval_metric": "logloss", "verbosity": 0}),
    ("DTC",   DecisionTreeClassifier, {"max_depth": 30}),
    ("Logit", LogisticRegression,     {"penalty": "l2", "max_iter": 500}),
    ("RFC",   RandomForestClassifier, {"n_estimators": 100}),
    ("KNN",   KNeighborsClassifier,   {"n_neighbors": 5}),
]
CLASSIFIER_NAMES = [n for n, _, _ in CLASSIFIER_SPECS]

INLINE_METHODS = [
    "Original", "SMOTE", "Borderline-SMOTE", "SMOTE-Tomek",
    "ADASYN", "KMeansSMOTE", "CTGAN", "TVAE",
]
if TABDDPM_AVAILABLE:
    INLINE_METHODS.append("TabDDPM")
if MATDIFF_AVAILABLE:
    INLINE_METHODS.append("MAT-Diff")
    
PRETRAINED_METHODS = ["DGOT", "GOIO"]
ALL_METHODS = INLINE_METHODS + PRETRAINED_METHODS

UTILITY_METRICS = ["Acc", "F1", "MCC", "BalAcc", "AUC_PR"]
FIDELITY_METRICS = ["MMD", "KS"]
PRIVACY_METRICS = ["DCR", "MIA"]


# ============================================================
# 3. DATA LOADING
# ============================================================
def load_dataset(name):
    target_file = f"{name}.csv"
    data_path = None
    for root, _, files in os.walk("/content"):
        if target_file in files:
            data_path = os.path.join(root, target_file)
            break
    if data_path is None:
        os.system("git clone https://github.com/MLneuers/DGOT.git "
                   "/content/DGOT > /dev/null 2>&1")
        data_path = f"/content/DGOT/datasets/{name}/{target_file}"

    print(f"Dataset      : {data_path}")
    df = pd.read_csv(data_path)
    df.columns = [c.strip() for c in df.columns]
    target_col = df.columns[-1] if "Target" not in df.columns else "Target"
    le = LabelEncoder()
    df[target_col] = le.fit_transform(df[target_col])
    X = df.drop(columns=[target_col]).values
    y = df[target_col].values
    dist = dict(zip(*np.unique(y, return_counts=True)))
    print(f"Features     : {X.shape[1]}")
    print(f"Samples      : {X.shape[0]}")
    print(f"Classes      : {len(dist)}")
    print(f"Distribution : {dist}")
    return X, y


# ============================================================
# 4. CLASSIFIER EVALUATION
# ============================================================
def build_classifiers():
    return {n: cls(**kw) for n, cls, kw in CLASSIFIER_SPECS}


def evaluate_classifiers(X_tr, y_tr, X_te, y_te):
    clfs = build_classifiers()
    res = {}
    for name in CLASSIFIER_NAMES:
        clf = clfs[name]
        clf.fit(X_tr, y_tr)
        y_pred = clf.predict(X_te)
        metrics = {
            "Acc":    accuracy_score(y_te, y_pred),
            "F1":     f1_score(y_te, y_pred, average="macro"),
            "MCC":    matthews_corrcoef(y_te, y_pred),
            "BalAcc": balanced_accuracy_score(y_te, y_pred),
        }
        # AUC-PR requires probability estimates
        try:
            if hasattr(clf, "predict_proba"):
                y_prob = clf.predict_proba(X_te)
                if len(np.unique(y_te)) == 2:
                    metrics["AUC_PR"] = average_precision_score(y_te, y_prob[:, 1])
                else:
                    from sklearn.preprocessing import label_binarize
                    y_bin = label_binarize(y_te, classes=np.unique(y_te))
                    metrics["AUC_PR"] = average_precision_score(
                        y_bin, y_prob, average="macro"
                    )
            else:
                metrics["AUC_PR"] = np.nan
        except Exception:
            metrics["AUC_PR"] = np.nan
        res[name] = metrics
    return res


# ============================================================
# 5. FIDELITY METRICS (MMD, KS)
# ============================================================
def compute_mmd_rbf(X_real, X_syn, gamma=None):
    """Maximum Mean Discrepancy with RBF kernel."""
    if X_syn is None or len(X_syn) == 0:
        return np.nan
    if gamma is None:
        gamma = 1.0 / X_real.shape[1]
    XX = np.exp(-gamma * cdist(X_real, X_real, "sqeuclidean"))
    YY = np.exp(-gamma * cdist(X_syn, X_syn, "sqeuclidean"))
    XY = np.exp(-gamma * cdist(X_real, X_syn, "sqeuclidean"))
    return float(XX.mean() + YY.mean() - 2 * XY.mean())


def compute_ks(X_real, X_syn):
    """Average per-feature Kolmogorov-Smirnov statistic."""
    if X_syn is None or len(X_syn) == 0:
        return np.nan
    ks_vals = []
    for j in range(X_real.shape[1]):
        stat, _ = ks_2samp(X_real[:, j], X_syn[:, j])
        ks_vals.append(stat)
    return float(np.mean(ks_vals))


# ============================================================
# 6. PRIVACY METRICS (DCR, MIA)
# ============================================================
def compute_dcr(X_real, X_syn):
    """Distance to Closest Record (lower = higher privacy risk)."""
    if X_syn is None or len(X_syn) == 0:
        return np.nan
    nn = NearestNeighbors(n_neighbors=1, algorithm="auto")
    nn.fit(X_real)
    dists, _ = nn.kneighbors(X_syn)
    return float(np.median(dists))


def compute_mia(X_train, X_syn, X_test):
    """Membership Inference Attack accuracy.
    Train a classifier to distinguish real train vs. real test samples
    using synthetic-augmented features. Lower = better privacy.
    A value near 0.5 indicates no privacy leakage."""
    if X_syn is None or len(X_syn) == 0:
        return np.nan
    try:
        n = min(len(X_train), len(X_test), 500)
        idx_tr = np.random.choice(len(X_train), n, replace=False)
        idx_te = np.random.choice(len(X_test), n, replace=False)
        X_mia = np.vstack([X_train[idx_tr], X_test[idx_te]])
        y_mia = np.array([1]*n + [0]*n)

        nn = NearestNeighbors(n_neighbors=5, algorithm="auto")
        nn.fit(X_syn)
        dists_tr, _ = nn.kneighbors(X_train[idx_tr])
        dists_te, _ = nn.kneighbors(X_test[idx_te])
        feats = np.vstack([dists_tr, dists_te])

        from sklearn.model_selection import cross_val_score
        mia_clf = LogisticRegression(max_iter=200)
        scores = cross_val_score(mia_clf, feats, y_mia, cv=3,
                                 scoring="accuracy")
        return float(np.mean(scores))
    except Exception:
        return np.nan


# ============================================================
# 7. RESAMPLING METHODS
# ============================================================
def apply_resampler(method, X_train, y_train, seed):
    """Returns (X_res, y_res, X_syn_only) or None.
    X_syn_only contains only the synthetic portion for fidelity/privacy."""
    try:
        n_orig = len(y_train)
        if method == "Original":
            return X_train, y_train, None

        elif method == "SMOTE":
            Xr, yr = SMOTE(random_state=seed).fit_resample(X_train, y_train)
        elif method == "Borderline-SMOTE":
            Xr, yr = BorderlineSMOTE(
                random_state=seed, kind="borderline-1"
            ).fit_resample(X_train, y_train)
        elif method == "SMOTE-Tomek":
            Xr, yr = SMOTETomek(random_state=seed).fit_resample(X_train, y_train)
        elif method == "ADASYN":
            Xr, yr = ADASYN(random_state=seed).fit_resample(X_train, y_train)
        elif method == "KMeansSMOTE":
            Xr, yr = KMeansSMOTE(
                random_state=seed, cluster_balance_threshold=0.01
            ).fit_resample(X_train, y_train)
        elif method == "CTGAN":
            return _generative_resample(X_train, y_train, "CTGAN")
        elif method == "TVAE":
            return _generative_resample(X_train, y_train, "TVAE")
        elif method == "TabDDPM":
            return _tabddpm_resample(X_train, y_train, seed)
        elif method == "MAT-Diff":
            return _matdiff_resample(X_train, y_train, seed)
        else:
            return None

        X_syn = Xr[n_orig:]
        return Xr, yr, X_syn if len(X_syn) > 0 else None

    except Exception:
        return None


def _generative_resample(X_train, y_train, model_type):
    try:
        from sdv.metadata import SingleTableMetadata
        from sdv.single_table import CTGANSynthesizer, TVAESynthesizer
    except ImportError:
        return None

    feat_cols = [str(i) for i in range(X_train.shape[1])]
    df = pd.DataFrame(X_train, columns=feat_cols)
    df["Target"] = y_train

    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(df)

    try:
        if model_type == "CTGAN":
            synth = CTGANSynthesizer(metadata, epochs=300, batch_size=500, verbose=False)
        else:
            synth = TVAESynthesizer(metadata, epochs=300, batch_size=500, verbose=False)
        synth.fit(df)
    except Exception:
        return None

    cc = pd.Series(y_train).value_counts()
    maj = cc.max()
    X_res, y_res = X_train.copy(), y_train.copy()
    all_syn_X = []

    for label, count in cc.items():
        if count < maj:
            needed = maj - count
            syn_cls = None
            
            for multiplier in [10, 20, 50, 100]:
                try:
                    total_gen = needed * multiplier
                    syn_all = synth.sample(total_gen)
                    syn_filtered = syn_all[syn_all["Target"] == label]
                    
                    if len(syn_filtered) >= needed:
                        syn_cls = syn_filtered.head(needed)
                        break
                    elif multiplier == 100 and len(syn_filtered) > 0:
                        syn_cls = syn_filtered
                        break
                except Exception:
                    continue
            
            if syn_cls is None or len(syn_cls) == 0:
                return None
            
            syn_vals = syn_cls[feat_cols].values
            X_res = np.vstack([X_res, syn_vals])
            y_res = np.hstack([y_res, syn_cls["Target"].values.astype(int)])
            all_syn_X.append(syn_vals)

    if not all_syn_X:
        return None
    return X_res, y_res, np.vstack(all_syn_X)


def _tabddpm_resample(X_train, y_train, seed):
    """TabDDPM resampling using GaussianMultinomialDiffusion."""
    if not TABDDPM_AVAILABLE:
        return None
    
    try:
        device = 'cuda' if torch and torch.cuda.is_available() else 'cpu'
        cc = Counter(y_train)
        maj = max(cc.values())
        X_res, y_res = X_train.copy(), y_train.copy()
        all_syn_X = []
        n_features = X_train.shape[1]
        
        for label, count in cc.items():
            if count < maj:
                needed = maj - count
                X_minority = X_train[y_train == label]
                
                if len(X_minority) < 2:
                    continue
                
                # Normalize data
                X_min = X_minority.min(axis=0)
                X_max = X_minority.max(axis=0)
                X_range = X_max - X_min
                X_range[X_range == 0] = 1.0
                X_minority_norm = (X_minority - X_min) / X_range
                
                # Create model
                model = MLPDiffusion(
                    d_in=n_features, num_classes=0, is_y_cond=False,
                    rtdl_params={'d_in': n_features, 'd_layers': [256, 256], 
                                'd_out': n_features, 'dropout': 0.0},
                    dim_t=128
                ).to(device)
                
                diffusion = GaussianMultinomialDiffusion(
                    num_classes=np.array([0]), num_numerical_features=n_features,
                    denoise_fn=model, num_timesteps=1000,
                    gaussian_loss_type='mse', scheduler='cosine', device=device
                ).to(device)
                
                optimizer = torch.optim.AdamW(diffusion.parameters(), lr=2e-4, 
                                              weight_decay=1e-5, betas=(0.9, 0.999))
                epochs = min(200, max(50, len(X_minority) // 2))
                batch_size = min(64, len(X_minority))
                
                # Train
                diffusion.train()
                X_tensor = torch.FloatTensor(X_minority_norm).to(device)
                
                for epoch in range(epochs):
                    perm = torch.randperm(len(X_tensor))
                    for i in range(0, len(X_tensor), batch_size):
                        indices = perm[i:i+batch_size]
                        x_batch = X_tensor[indices]
                        optimizer.zero_grad()
                        out_dict = {}
                        loss_multi, loss_gauss = diffusion.mixed_loss(x_batch, out_dict)
                        loss = loss_multi + loss_gauss
                        loss.backward()
                        optimizer.step()
                
                # Sample
                diffusion.eval()
                with torch.no_grad():
                    y_dist = torch.ones(1, device=device)
                    x_gen, y_gen = diffusion.sample_all(
                        num_samples=needed, batch_size=min(512, needed),
                        y_dist=y_dist, ddim=False
                    )
                    
                    if x_gen is not None and len(x_gen) > 0:
                        x_gen_np = x_gen.cpu().numpy()
                        x_gen_denorm = x_gen_np * X_range + X_min
                        X_res = np.vstack([X_res, x_gen_denorm])
                        y_res = np.hstack([y_res, np.full(len(x_gen_denorm), label)])
                        all_syn_X.append(x_gen_denorm)
        
        if not all_syn_X:
            return None
        return X_res, y_res, np.vstack(all_syn_X)
    
    except Exception:
        return None


def _matdiff_resample(X_train, y_train, seed):
    """MAT-Diff resampling using MATDiffPipeline."""
    if not MATDIFF_AVAILABLE:
        return None
    
    try:
        device = 'cuda' if torch and torch.cuda.is_available() else 'cpu'
        
        # Use default config (dataset-specific config optional)
        cfg = {
            'd_model': 128, 'd_hidden': 256,
            'n_blocks': 3, 'n_heads': 4,
            'n_phases': 3, 'total_timesteps': 1000,
            'dropout': 0.1, 'lr': 1e-4,
            'weight_decay': 1e-5, 'batch_size': 256,
            'privacy_quantile': 0.05, 'epochs': 100
        }
        
        # Try to load dataset-specific config if available
        try:
            from mat_diff.config import get_matdiff_config
            # DATASET_NAME is a global variable defined at module level
            cfg.update(get_matdiff_config(DATASET_NAME))
        except Exception:
            pass  # Use default config
        
        pipeline = MATDiffPipeline(
            device=device,
            d_model=cfg.get("d_model", 128),
            d_hidden=cfg.get("d_hidden", 256),
            n_blocks=cfg.get("n_blocks", 3),
            n_heads=cfg.get("n_heads", 4),
            n_phases=cfg.get("n_phases", 3),
            total_timesteps=cfg.get("total_timesteps", 1000),
            dropout=cfg.get("dropout", 0.1),
            lr=cfg.get("lr", 1e-4),
            weight_decay=cfg.get("weight_decay", 1e-5),
            privacy_quantile=cfg.get("privacy_quantile", 0.05),
        )
        
        # Fit
        epochs = cfg.get("epochs", 100)
        batch_size = cfg.get("batch_size", 256)
        pipeline.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=False)
        
        # Sample
        X_syn, y_syn_labels = pipeline.sample()
        
        if len(X_syn) > 0:
            X_aug = np.vstack([X_train, X_syn])
            y_aug = np.hstack([y_train, y_syn_labels])
            return X_aug, y_aug, X_syn
        else:
            return None
    
    except Exception:
        return None


# ============================================================
# 8. PRETRAINED LOADERS (DGOT / GOIO)
# ============================================================
def load_pretrained(method, dataset_name, fold_idx, X_train, y_train, X_test):
    """Load synthetic data from pretrained DGOT/GOIO.
    Returns (X_aug, y_aug, X_syn_only, X_test_loaded, y_test_loaded) or None.
    """
    if method == "DGOT":
        return _load_dgot(dataset_name, fold_idx, X_train, y_train)
    elif method == "GOIO":
        return _load_goio(dataset_name, fold_idx, X_train, y_train)
    return None


def _load_dgot(name, fold, X_train, y_train):
    base = "/content/DGOT"
    classic = f"{base}/datasets/{name}/CLASSIC/exp{fold}"
    syn_dir = f"{base}/saved_log/DGOT/{name}/exp{fold}"
    if not os.path.isdir(syn_dir) or not os.path.isdir(classic):
        return None
    try:
        syn_files = (glob.glob(f"{syn_dir}/syn_*.npy") +
                     glob.glob(f"{syn_dir}/syn_*.csv"))
        if not syn_files:
            return None
        all_syn_X, all_syn_y = [], []
        for sf in syn_files:
            s = pd.read_csv(sf).values if sf.endswith(".csv") else np.load(sf)
            all_syn_X.append(s[:, :-1])
            all_syn_y.append(s[:, -1])
        syn_X = np.vstack(all_syn_X)
        syn_y = np.hstack(all_syn_y)
        X_aug = np.vstack([X_train, syn_X])
        y_aug = np.hstack([y_train, syn_y])
        return X_aug, y_aug, syn_X
    except Exception:
        return None


def _load_goio(name, fold, X_train, y_train):
    base = "/content/GOIO"
    syn_path = f"{base}/synthetic/{name}/exp{fold}/CLDM/syn_{name}.csv"
    if not os.path.isfile(syn_path):
        return None
    try:
        syn = pd.read_csv(syn_path).values
        syn_X, syn_y = syn[:, :-1], syn[:, -1]
        cc = Counter(y_train)
        maj = max(cc.values())
        aug_X, aug_y = [], []
        for label, count in cc.items():
            if count < maj:
                needed = int(maj - count)
                mask = syn_y == label
                cls_X = syn_X[mask]
                if len(cls_X) == 0:
                    continue
                replace = len(cls_X) < needed
                idx = np.random.choice(len(cls_X), needed, replace=replace)
                aug_X.append(cls_X[idx])
                aug_y.append(np.full(needed, label))
        if not aug_X:
            return None
        syn_combined = np.vstack(aug_X)
        X_out = np.vstack([X_train, syn_combined])
        y_out = np.hstack([y_train, np.hstack(aug_y)])
        return X_out, y_out, syn_combined
    except Exception:
        return None


# ============================================================
# 9. RESULTS STORAGE
# ============================================================
def init_results():
    r = {}
    for m in ALL_METHODS:
        r[m] = {
            clf: {met: [] for met in UTILITY_METRICS}
            for clf in CLASSIFIER_NAMES
        }
        r[m]["_fidelity"] = {met: [] for met in FIDELITY_METRICS}
        r[m]["_privacy"] = {met: [] for met in PRIVACY_METRICS}
    return r


# ============================================================
# 10. MAIN EXPERIMENT
# ============================================================
def run_experiment():
    X_raw, y_raw = load_dataset(DATASET_NAME)
    results = init_results()

    dgot_ok = os.path.isdir("/content/DGOT/saved_log")
    goio_ok = os.path.isdir("/content/GOIO/synthetic")

    if not dgot_ok:
        print("[INFO] DGOT outputs not found. Train separately first.")
    if not goio_ok:
        print("[INFO] GOIO outputs not found. Train separately first.")

    total = N_SEEDS * N_FOLDS
    done = 0
    print(f"\nProtocol     : {N_SEEDS} seeds x {N_FOLDS} folds = {total} iterations")
    print(f"Classifiers  : {CLASSIFIER_NAMES}")
    print(f"Methods      : {ALL_METHODS}")
    print("=" * 72)

    for seed in range(N_SEEDS):
        skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=seed)

        for fold, (tr_idx, te_idx) in enumerate(skf.split(X_raw, y_raw)):
            X_tr, X_te = X_raw[tr_idx], X_raw[te_idx]
            y_tr, y_te = y_raw[tr_idx], y_raw[te_idx]

            for method in INLINE_METHODS:
                out = apply_resampler(method, X_tr, y_tr, seed)
                if out is None:
                    continue
                X_res, y_res, X_syn = out

                clf_res = evaluate_classifiers(X_res, y_res, X_te, y_te)
                for cn in CLASSIFIER_NAMES:
                    for met in UTILITY_METRICS:
                        results[method][cn][met].append(clf_res[cn].get(met, np.nan))

                if X_syn is not None and len(X_syn) > 0:
                    minority_mask = np.isin(y_tr, [
                        k for k, v in Counter(y_tr).items()
                        if v < max(Counter(y_tr).values())
                    ])
                    X_minority = X_tr[minority_mask]
                    if len(X_minority) > 0:
                        results[method]["_fidelity"]["MMD"].append(
                            compute_mmd_rbf(X_minority, X_syn))
                        results[method]["_fidelity"]["KS"].append(
                            compute_ks(X_minority, X_syn))
                        results[method]["_privacy"]["DCR"].append(
                            compute_dcr(X_tr, X_syn))
                        results[method]["_privacy"]["MIA"].append(
                            compute_mia(X_tr, X_syn, X_te))

            for method in PRETRAINED_METHODS:
                if method == "DGOT" and not dgot_ok:
                    continue
                if method == "GOIO" and not goio_ok:
                    continue
                out = load_pretrained(method, DATASET_NAME, fold, X_tr, y_tr, X_te)
                if out is None:
                    continue
                X_aug, y_aug, X_syn = out
                clf_res = evaluate_classifiers(X_aug, y_aug, X_te, y_te)
                for cn in CLASSIFIER_NAMES:
                    for met in UTILITY_METRICS:
                        results[method][cn][met].append(clf_res[cn].get(met, np.nan))

                if X_syn is not None and len(X_syn) > 0:
                    minority_mask = np.isin(y_tr, [
                        k for k, v in Counter(y_tr).items()
                        if v < max(Counter(y_tr).values())
                    ])
                    X_minority = X_tr[minority_mask]
                    if len(X_minority) > 0:
                        results[method]["_fidelity"]["MMD"].append(
                            compute_mmd_rbf(X_minority, X_syn))
                        results[method]["_fidelity"]["KS"].append(
                            compute_ks(X_minority, X_syn))
                        results[method]["_privacy"]["DCR"].append(
                            compute_dcr(X_tr, X_syn))
                        results[method]["_privacy"]["MIA"].append(
                            compute_mia(X_tr, X_syn, X_te))

            done += 1
            print(f"  Progress: {done}/{total} "
                  f"(Seed {seed}, Fold {fold})", end="\r")

        print(f"  Seed {seed:>2d} complete ({seed+1}/{N_SEEDS})"
              + " " * 30)

    print("=" * 72)
    return results


# ============================================================
# 11. REPORTING
# ============================================================
def _fmt(vals):
    if not vals or all(np.isnan(v) for v in vals):
        return "--"
    v = [x for x in vals if not np.isnan(x)]
    if not v:
        return "--"
    return f"{np.mean(v):.4f} +/- {np.std(v):.4f}"


def print_utility_table(results, metric, label):
    print(f"\n{'':->96}")
    print(f"  {label}")
    print(f"{'':->96}")
    hdr = f"{'Method':<18}"
    for c in CLASSIFIER_NAMES:
        hdr += f" | {c:>15}"
    hdr += f" | {'AVG':>15}"
    print(hdr)
    print("-" * 96)

    for m in ALL_METHODS:
        row = f"{m:<18}"
        means = []
        for c in CLASSIFIER_NAMES:
            vals = results[m][c][metric]
            row += f" | {_fmt(vals):>15}"
            clean = [v for v in vals if not np.isnan(v)]
            if clean:
                means.append(np.mean(clean))
        if means:
            row += f" | {np.mean(means):>15.4f}"
        else:
            row += f" | {'--':>15}"
        print(row)
    print("-" * 96)


def print_fidelity_privacy_table(results):
    print(f"\n{'':->72}")
    print("  Fidelity and Privacy Metrics (mean +/- std)")
    print(f"{'':->72}")
    print(f"{'Method':<18} | {'MMD':>15} | {'KS':>15} | {'DCR':>15} | {'MIA':>15}")
    print("-" * 72)

    for m in ALL_METHODS:
        mmd = _fmt(results[m]["_fidelity"]["MMD"])
        ks = _fmt(results[m]["_fidelity"]["KS"])
        dcr = _fmt(results[m]["_privacy"]["DCR"])
        mia = _fmt(results[m]["_privacy"]["MIA"])
        print(f"{m:<18} | {mmd:>15} | {ks:>15} | {dcr:>15} | {mia:>15}")
    print("-" * 72)


def print_compact_summary(results):
    print(f"\n{'=' * 90}")
    print("Compact Summary (averaged across all 5 classifiers)")
    print(f"{'=' * 90}")
    print(f"{'Method':<18} | {'F1-Macro':>18} | {'MCC':>18} | "
          f"{'BalAcc':>18} | {'AUC-PR':>18}")
    print("-" * 90)

    for m in ALL_METHODS:
        vals = {}
        for met in ["F1", "MCC", "BalAcc", "AUC_PR"]:
            all_v = []
            for c in CLASSIFIER_NAMES:
                all_v.extend(results[m][c][met])
            vals[met] = _fmt(all_v)
        print(f"{m:<18} | {vals['F1']:>18} | {vals['MCC']:>18} | "
              f"{vals['BalAcc']:>18} | {vals['AUC_PR']:>18}")
    print("-" * 90)


def export_csv(results, path="baseline_results.csv"):
    rows = []
    for m in ALL_METHODS:
        for c in CLASSIFIER_NAMES:
            for met in UTILITY_METRICS:
                vals = [v for v in results[m][c][met] if not np.isnan(v)]
                if vals:
                    rows.append({
                        "Method": m, "Classifier": c, "Metric": met,
                        "Mean": np.mean(vals), "Std": np.std(vals),
                        "N": len(vals)
                    })
        for met in FIDELITY_METRICS:
            vals = [v for v in results[m]["_fidelity"][met] if not np.isnan(v)]
            if vals:
                rows.append({
                    "Method": m, "Classifier": "ALL", "Metric": met,
                    "Mean": np.mean(vals), "Std": np.std(vals),
                    "N": len(vals)
                })
        for met in PRIVACY_METRICS:
            vals = [v for v in results[m]["_privacy"][met] if not np.isnan(v)]
            if vals:
                rows.append({
                    "Method": m, "Classifier": "ALL", "Metric": met,
                    "Mean": np.mean(vals), "Std": np.std(vals),
                    "N": len(vals)
                })
    pd.DataFrame(rows).to_csv(path, index=False)
    print(f"\nResults exported to {path}")


# ============================================================
# 12. ENTRY POINT
# ============================================================
if __name__ == "__main__":
    results = run_experiment()

    for met, label in [
        ("F1",     "F1-Macro (mean +/- std)"),
        ("MCC",    "MCC (mean +/- std)"),
        ("Acc",    "Accuracy (mean +/- std)"),
        ("BalAcc", "Balanced Accuracy (mean +/- std)"),
        ("AUC_PR", "AUC-PR (mean +/- std)"),
    ]:
        print_utility_table(results, met, label)

    print_fidelity_privacy_table(results)
    print_compact_summary(results)
    export_csv(results)
